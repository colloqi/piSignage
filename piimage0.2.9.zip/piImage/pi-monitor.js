// need to add in install.sh sudo npm install -g forever-monitor
//
var forever = require('forever-monitor');

var child = new (forever.Monitor)('pi-server.js', {
    max: 3,
    silent: false,
    killTree: true,

    spinSleepTime: 2000,

    append: true,
    logFile: '/home/pi/forever.log',
    outFile: '/home/pi/forever_out.log',
    errFile: '/home/pi/forever_err.log'

});

var stable = false;
child.on('exit', function () {
    console.log('pi-server.js has exited after 3 restarts');
    //Looks like we, need to downgrade the pi-server image
    if (!stable)   {
        var fs = require('fs'),
            spawn = require('child_process').spawn,
            out = fs.openSync('/home/pi/forever.log', 'a'),
            err = fs.openSync('/home/pi/forever.log', 'a');

        var downgrade = spawn('misc/downgrade.sh', [], {
            detached: true,
            stdio: [ 'ignore', out, err ]
        });

        downgrade.unref();
    }
});

child.start();

setTimeout(function(){
    stable = true;
}, 10 * 60 * 1000)

