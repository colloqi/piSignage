#!/bin/sh
#********************************************************************
#ADD release specific changes and be sure to delete after the release
#********************************************************************

echo "release specific commands"
cp misc/wgetrc ~/.wgetrc
#********************************************************************