#!/bin/sh
####################################################################
# this script will take care of new release and auto update (modules should be attached)
#first kill forever process
#remove the current folder
#get file from the link
#change ownership
#reboot
#####################################################################

# kill forever process
pkill -f forever
pkill -f node
pkill -f uzbl
pkill -f omx

cd ~
#sudo apt-get -qq update
#sudo apt-get -y -qq upgrade

echo "rolling back to previous release"

rm -rf  ~/piSignagePro.problem
mv  ~/piSignagePro  ~/piSignagePro.problem
mv  ~/piSignagePro.prev  ~/piSignagePro

sync

sudo reboot
