#!/bin/sh
####################################################################
# this script will take care of new release and auto update (modules should be attached)
#first kill forever process
#remove the current folder
#get file from the link
#change ownership
#reboot
#####################################################################

cd ~

echo "get the new server release file"
wget $1
if [ $? -ne 0 ]; then
	echo "wget could not get the release file" 1>&2
	exit 1
fi

# kill forever process
pkill -f forever
pkill -f node
pkill -f uzbl
pkill -f omx

echo "saving the current image"
rm -rf  ~/piSignagePro.prev
mv ~/piSignagePro ~/piSignagePro.prev

echo "unzipping the pi image"
unzip $2
mv ~/piImage ~/piSignagePro

echo "copying configuration files"
cp ~/piSignagePro.prev/config/_config.json ~/piSignagePro/config
cp ~/piSignagePro.prev/config/_settings.json ~/piSignagePro/config

echo "copying the previous node modules"
cp -R ~/piSignagePro.prev/node_modules ~/piSignagePro

rm $2
cd ~/piSignagePro

chmod +x misc/upgrade.sh
chmod +x misc/downgrade.sh

echo "installing npm packages"
npm install

file="misc/onetime.sh"
if [ -f "$file" ]
then
	chmod +x $file
	$file
fi

sync

rm ~/piSignagePro/misc/install.sh ~/piSignagePro/misc/autostart

sudo reboot
