'use strict';

var path = require('path');

var rootPath = process.cwd();

var dataDir = path.join(rootPath, '/data');

var assetDir = path.join(rootPath, '/../media');

module.exports = {
    root:                   rootPath,
    dataDir:                dataDir,
    uploadDir:              assetDir,
    syncDir:                path.join(dataDir, '/sync_folders'),
    syncDirPath:            path.join(dataDir, '/sync_folders/'),
    viewDir:                path.join(rootPath, '/app/views'),
    mediaDir:               assetDir,
    mediaPath:              assetDir + '/',
    thumbnailDir:           assetDir + '/_thumbnails',
    defaultPlaylist:        "default",

    defaultTemplateDir:     rootPath+ "/templates/",
    defaultTemplate:        rootPath+ "/templates/t1_template.jade",

    mongo: {
        options: {
            db: {
                safe: true
            }
        }
    },
    session: {
        secret: 'piSignage'
    },

    videoRegex:             /(mp4|mov|m4v|avi)$/i,
    imageRegex:             /(jpg|jpeg|png|gif)$/i,
    noticeRegex:            /\.html$/
};
