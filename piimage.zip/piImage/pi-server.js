'use strict';

process.env.NODE_ENV = 'pi';

var express = require('express'),
    auth = require('http-auth');

var config = require('./config/config'),
    ioclient = require('socket.io-client');

var assets = require('./app/controllers/assets'),
    playlists = require('./app/controllers/playlists'),
    piMain = require('./app/controllers/pi-main');

if (config.btsync) {
    require('./app/controllers/btsync').start(function(err){
        if (err)
            console.log("btsync start error: "+err);
    });
}

var piBasic = auth.basic({
    realm:  "pi",
    file:   config.root + "/htpasswd"
});

var app = express();

app.use(allowCrossDomain);

app.use(express.static(config.root + '/public'))

app.use(auth.connect(piBasic));

app.use('/media',express.static(config.mediaDir))

app.set('view engine', 'jade')

app.set('views', config.viewDir);

app.configure(function () {

    // bodyParser should be above methodOverride
    app.use(express.bodyParser({uploadDir:config.mediaDir}))
    app.use(express.methodOverride())

    // routes should be at the last
    app.use(app.router)

    // custom error handler
    app.use(function (err, req, res, next) {
        if (~err.message.indexOf('not found')) return next()
        console.error(err.stack)
        res.status(500).render('500')
    })

    app.use(function (req, res, next) {
        res.status(404).render('404', { url: req.originalUrl })
    })

})


addRoutes(app);

piMain.startClient(ioclient);

app.listen(config.port, function() {
    console.log("Express server listening on port " + config.port);
});

function allowCrossDomain(req, res, next) {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
    res.header('Access-Control-Allow-Credentials', true);
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type,Content-Length, X-Requested-With,origin,accept');

    if (req.method == 'OPTIONS') {
        res.send(200);
    }
    else {
        next();
    }
}

function addRoutes(app) {

    app.get('/api/files', assets.index);
    app.get('/api/files/:file', assets.getFileDetails);
    app.post('/api/files', assets.createFiles);
    app.post('/api/files/:file', assets.renameFile);
    app.delete('/api/files/:file', assets.deleteFile);

    app.get('/api/notices/:file', assets.getNotice);
    app.post('/api/notices', assets.createNotice);
    app.post('/api/notices/:file', assets.createNotice);
    app.delete('/api/notices/:file', assets.deleteFile);

    app.get('/api/playlists', playlists.index);
    app.get('/api/playlists/:file', playlists.getPlaylist);
    app.post('/api/playlists', playlists.createPlaylist);
    app.post('/api/playlists/:file', playlists.savePlaylist);


    app.post('/api/play/playlists/:file', piMain.playPlaylist);
    app.post('/api/play/files/:file', piMain.playFile);

    app.get('/api/status', piMain.getStatus);

    app.get('/api/settings', piMain.getSettings);
    app.post('/api/settings', piMain.saveSettings);
    app.post('/api/settings/update',piMain.getupdate);

    app.get('*', function(req, res){
        res.render('index-pi');
    })
}
