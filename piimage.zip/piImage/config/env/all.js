'use strict';

var path = require('path');

var rootPath = path.normalize(__dirname + '/../..');
var dataDir = path.join(rootPath, '/data');

var assetDir = path.join(rootPath, '/../media');

module.exports = {
    root:                   rootPath,
    dataDir:                dataDir,
    uploadDir:              assetDir,
    syncDir:                path.join(dataDir, '/sync_folders'),
    syncDirPath:            path.join(dataDir, '/sync_folders/'),
    viewDir:                path.join(rootPath, '/app/views'),
    mediaDir:               assetDir,
    mediaPath:              assetDir + '/',
    defaultPlaylist:        "default",

    defaultTemplateDir:     rootPath+ "/templates/",
    defaultTemplate:        rootPath+ "/templates/t1_template.jade",

    mongo: {
        options: {
            db: {
                safe: true
            }
        }
    },
    session: {
        secret: 'piSignage'
    }
};
