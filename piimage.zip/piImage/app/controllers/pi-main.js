'use strict';

var config = require('../../config/config'),
    viewer = require('./pi-viewer'),
    exec = require('child_process').exec,
    fs= require('fs'),
    async= require('async'),
    rest= require('../others/restware'),
    _= require('lodash'),
    jade = require('jade'),
    wget = require('./pi-wget'),
    os = require('os');

var piGlobals = {
        playlistOn:         false,
        currentPlaylist:    null,
        playlistStarttime:  null,
        diskSpaceUsed:      null,
        diskSpaceAvailable: null,
        duration:           null,
        tvStatus:           true
    },
    settings = {
        name:           "piSignage",
        note:           "Add a small optional note here",
        cpuSerialNumber: "unknown",
        myIpAddress: "",
        secret: ""
    },
    piReady = 0,
    myIpAddress,
    playlistContent,
    playlistChanged = false;

(function ipaddress(){
    var ipdata= os.networkInterfaces();
    for(var key in ipdata){
        var interfaces= ipdata[key];
        for(var key in interfaces){
            var target= interfaces[key];
            if(target.family == 'IPv4' && !target.internal)
                myIpAddress=  target.address;
        }
    }
}());

var playPlaylist = function(play,plname, cb) {
    if (play) {
        if (piGlobals.playlistOn ) {
            return cb("Already playing started");
        }

        piGlobals.playlistOn = true;
        if (plname && plname != 'default') {
            piGlobals.currentPlaylist = plname;
        } else {
            piGlobals.currentPlaylist = config.defaultPlaylist;
        }
        try {
            playlistContent = fs.readFileSync(config.mediaPath + "__" + piGlobals.currentPlaylist +".json",'utf8')
            var pl = JSON.parse(playlistContent);
            var files = pl.assets;
            //var ticker =  "Welcome to PiSignage - Smartphone controlled Signage Player.&nbsp;&nbsp;&nbsp;&nbsp;" +
            //                "With PiSignage, making Displays work for you is simple, fast and hassle-free."
            var ticker;
            if (pl.settings && pl.settings.ticker && pl.settings.ticker.enable)
                ticker = pl.settings.ticker.messages;
        } catch (e) {
            piGlobals.playlistOn = false;
            return cb("There seems to be no such playlist file: "+piGlobals.currentPlaylist+";error="+ e.code);
        }

        var err = viewer.startPlay(files, ticker);
        if (err) {
            piGlobals.playlistOn = false;
            return cb(err);
        } else {
            piGlobals.playlistStarttime = Date.now();
            exports.writeToConfig();
            piGlobals.duration = 0;
            return cb(null,piGlobals);
        }
    } else {
        if (!piGlobals.playlistOn )
            cb("Already playing stopped");

        piGlobals.playlistOn = false;
        var err = viewer.stopPlay();
        piGlobals.playlistStarttime = null;
        piGlobals.duration = Math.floor((Date.now() - piGlobals.playlistStarttime)/60000);
        exports.writeToConfig();
        return cb(null,piGlobals);
    }
}

var changePlaylist = function(cb) {
    var startPl = function () {
        playPlaylist(true,piGlobals.currentPlaylist,function(err,result){
            if (err) {
                console.log("start Playlist error: "+err);
            }
            sendSocketIoStatus();
            cb(err,result);
        })
    }
    playPlaylist(false,piGlobals.currentPlaylist,function(err) {
        if (err) {
            console.log("stop Playlist error: "+err);
        }
        setTimeout(startPl,3000);
    })
}

exports.writeToSettings = function(){
    fs.writeFileSync(config.settingsFile,
        JSON.stringify(settings, null, 4));
    exec('sync')
//    ,function(err) {
//            if (err) throw err;
//    })
}

exports.writeToConfig= function(obj){
    if (obj) {
        for (var key in Object.keys(obj))
            piGlobals[key] = obj[key];
    }
    fs.writeFileSync(config.poweronConfig, JSON.stringify(piGlobals, null, 4));
    exec('sync')
//    , function(err){
//        if (err) throw err;
//    })
}

exports.updateDiskStatus = function () {
    exec('df -h /').stdout.on('data',function(data){
        //console.log("the total usage" +data);
        var strings = data.replace(/\s{2,}/g, ' ').split(" ");
        piGlobals.diskSpaceUsed = strings[strings.length-2];
        piGlobals.diskSpaceAvailable = strings[strings.length-3];
        piReady = piReady | 1;
    })

}



exports.playFile = function(req,res){
    if (req.body.play) {
        var err;
        if (req.params['playfile']) {
            err = viewer.startPlay({filename: req.params['playfile'],duration:100000});
        } else {
            err = "Nothing to Play";
        }

        if (err) {
            return rest.sendError(res,err);
        } else {
            return rest.sendSuccess(res,'Started playing file',piGlobals);
        }
    }

    if (req.body.stop) {
        var err = viewer.stopPlay();
        rest.sendSuccess(res,'Stopped playing file',piGlobals);
        return;
    }
}


exports.playPlaylist = function (req,res){

    if (req.body.play) {
        playPlaylist(true,req.params['file'],function(err,result){
            if (err)
                return rest.sendError(res,"Already playing started");
            else {
                return rest.sendSuccess(res,'Started playlist',result);
            }
        })
    } else if (req.body.stop ) {
        playPlaylist(false, req.params['file'], function (err, result) {
            if (err)
                return rest.sendError(res, err);
            else {
                return rest.sendSuccess(res, 'Stopped playlist', result);
            }
        })
    }
}

exports.getStatus = function(req, res){
    if (piGlobals.playlistOn)
        piGlobals.duration = Math.floor((Date.now() - piGlobals.playlistStarttime)/60000);
    else
        piGlobals.duration = 0;
    return rest.sendSuccess(res, 'Status Check', piGlobals);
}


exports.getSettings = function(req, res){
    return rest.sendSuccess(res, 'Settings', {name: settings.name,note:settings.note});
}

exports.saveSettings =  function(req, res){
    settings.name = req.body.name;
    settings.note = req.body.note;
    
    fs.writeFile(config.settingsFile,
        JSON.stringify(settings, null, 4),
        function(err) {
            if (err) {
                return rest.sendError(res,'Settings write error',err);
            } else {
                return rest.sendSuccess(res,"Settings Saved",{name: settings.name,note:settings.note});
            }

        }
    );
}
 exports.getupdate = function(req,res){
        var oldversion , newversion,getpackage,fdata;
        console.log('clicked hello >>>>>>>>>>>>>>>>>>>>>>');
        getpackage = exec('wget --directory-prefix=/tmp/ https://www.dropbox.com/s/2fjpyhaksvq7w1k/package.json');
        
        getpackage.on('exit',function(data){
                console.log('stdout loop');
                console.log(data);
                fs.readFile('/tmp/package.json','utf8',function(err,data1){
                        if (err) {
                               throw err;
                        }
                        console.log("/tmp/package reading");
                        fdata = JSON.parse(data1);
                        newversion = fdata.version;
                        
                });
                fs.readFile('/home/ariem/piSignagePro/package.json','utf8',function(err,data2){
                        if (err) {
                               throw err;
                        }
                        var fdata = JSON.parse(data2);
                        console.log("/pisignagepro package reading");
                        console.log(fdata.version +"   "+ newversion);
                        oldversion = fdata.version;
                        oldversion == newversion? uptodate(data2) : getnewupdate(); 
                });
        });
        
        function uptodate(data) {
                console.log('uptodate>>>>>>>>>>>');
                return rest.sendSuccess(res,'Already at latest version', data);
        }
        
        function getnewupdate() {
                var updatecmd = exec('sh ~/piSignagePro/misc/autoupdate.sh');
                console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.entered ');
                updatecmd.stdout.on('data',function(data){
                        console.log(data);
                });
                updatecmd.on('exit',function(data){
                        if (!data) {
                                return rest.sendSuccess(res,'Update Complete!', data);
                        }else{
                                return rest.sendError(res,'Update Failed!',data);
                        }
                })
        }
}
displayHelpScreen();

exports.updateDiskStatus();
//read the last config on poweron and start play if necessary
fs.readFile ( config.poweronConfig,'utf8', function(err,data){
    if (!err) {
        try {
            var cfgdata = JSON.parse(data);
        } catch(e) {
            fs.unlink(config.poweronConfig);    //corrupt file
        }
        if (cfgdata) {
            piGlobals = cfgdata;
            piGlobals.playlistStarttime = null;

            if (piGlobals.playlistOn) {
                setTimeout(function(){
                    changePlaylist(function(err){
                        sendSocketIoStatus();
                    })
                },3500);
            }
        } else {
            piGlobals.request = true;
            console.log("Unable to JSON parse _config.json file");
        }
    } else {
        piGlobals.request = true;
        console.log("there seems to be no _config.json file: "+err);
    }
    piReady = piReady | 2;
    sendSocketIoStatus();
});


function displayHelpScreen(){
    var html,
        cpuserial= settings.cpuSerialNumber,
        format= cpuserial.slice(0,4)+'-'+cpuserial.slice(4,8)+'-'+cpuserial.slice(8,12)+'-'+cpuserial.slice(12,16);    
    fs.readFile('./app/views/emptynotice.jade','utf8', function(err, data){
        if(err) console.log(err);
        html= jade.compile(data)({ ipaddress: myIpAddress || null, serverId: format});
        fs.writeFile(config.mediaPath + '_emptynotice.html', html, function(err){
            if (err) console.log(err);
            viewer.startPlay([{filename: '_emptynotice.html',duration:30}]);
        })
    })
}

//Server communication
fs.readFile ( config.settingsFile,'utf8', function(err,data) {
    if (!err) {
        try {
            settings = JSON.parse(data);
        } catch (e) {
            //corrupt file
        }
    }

    settings.myIpAddress = myIpAddress;
    if (!settings.secret) {
        piGlobals.request = true;
    } else if (!config.btsync){
        wget.getGroupFiles(settings.secret, function(err){     //check for pending downloads
            console.log("wget status: "+err);
            checkChangeAndReply();
        });
    }

    //Socket.io based server communication
    exec("cat /proc/cpuinfo |grep Serial|awk '{print $3 }'").stdout.on('data',function(data){
        console.log("cpu serial number: " +data);
        settings.cpuSerialNumber = data.slice(0,data.length-1);
        piReady = piReady | 8;
        sendSocketIoStatus();
    })
})

var socket = null,
    ioclient;

exports.startClient =  function(sio) {
    var inProgress;
    if (sio)
        ioclient = sio;

    if (socket) {
        try {
            socket.disconnect();
        } catch (e) {
            console.log("socket disconnect exception: "+ e.code);
        }
        socket = null;
    }

    socket = ioclient.connect(config.server,{ 'force new connection': true });              //add server address
    console.log("starting socketio")

    socket.on('connect', function () {
        // socket connected
        console.log("socket.io: connected to server");
        piReady = piReady | 4;
        sendSocketIoStatus();
    });

    socket.on('reconnect_failed', function () {
        console.log("socket.io: reconnect failed event");
        piReady = piReady & ~4;
    });

    socket.on('connect_failed', function () {
        console.log("socket.io: connect failed event");
        piReady = piReady & ~4;
    });

    socket.on('error', function () {
        console.log("socket.io: error  event");
        piReady = piReady & ~4;
    });

    socket.on('status', function () {
        sendSocketIoStatus();
    });

    socket.on('secret', function (secret) {
        addSyncFolder (secret);
        playlistChanged = true;
    });

    socket.on('shell', function (cmd) {
        runCmd(cmd);
    });

    socket.on('config', function (config) {
        playlistChanged = true;
        piGlobals.request = false;
        if (config.secret) {
            addSyncFolder (config.secret);
        }
        if (config.currentPlaylist) {
            piGlobals.currentPlaylist = config.currentPlaylist;
            console.log(config.currentPlaylist);
        }
    });

    socket.on('sync', function (playlist) {
        console.log("sync initiated at server: "+(new Date()).toLocaleString());
        playlistChanged = true;
        if (playlist) {
            piGlobals.currentPlaylist = playlist;
        }
        if (!config.btsync) {
            //invoke wget
            wget.getGroupFiles(settings.secret, function(err){
                if (!err) {
                    console.log("COPIED SERVER FILES "+settings.secret+ " SUCCESSFULLY.");
                }
                else {
                    console.log("FAILED COPYING SERVER FILES:: "+err);
                }
                checkChangeAndReply();
            });
        }
    });

    socket.on('restart', function () {
        if (inProgress)
            return;
        inProgress = true;
        console.log("**** Restarting the playlist ****")
        changePlaylist(function(err){
            inProgress = false;
        })
    });

     scheduleNext();
}

function scheduleNext() {
    setTimeout(function () {
        if (!socket || !(piReady & 4)) {
            console.log("re-connecting socketio")
            exports.startClient();
            return;
        }
        sendSocketIoStatus();
        scheduleNext();
    }, 1 * 60 * 1000)
}


function sendSocketIoStatus () {
    if (piReady < 10) {
        console.log("yet to get cpuid and config data");
        return;
    }
    if (piGlobals.playlistOn)
        piGlobals.duration = Math.floor((Date.now() - piGlobals.playlistStarttime)/60000);
    else
        piGlobals.duration = 0;
    console.log("emit status");
    if (socket)
        socket.emit('status', settings, piGlobals);
    else
        console.log("*** Error: socket does not exist")
}

var underProgress = false;

function addSyncFolder (secret) {
    if (underProgress)
        return;
    underProgress = true;
    console.log("going to add secret key: "+secret);

    var saveAndReply = function(err) {
        underProgress = false;
        settings.secret = secret;
        exports.writeToSettings();
        socket.emit('secret_ack', err);
    }

    if (config.btsync) {
        require('./btsync').addSecretKey(secret, settings.cpuSerialNumber, function (err) {
            console.log("added secret key to sync: " + err);
            saveAndReply(err);
        });
    } else {
        if (secret != settings.secret) {    //group is changed, delete the old files

            var settingsFile = [
                '_config.json',
                '_settings.json'
            ]
            var path = config.mediaDir;
            fs.readdir(path, function (err, files) {
                if (err)
                    console.log("read dir error for delete files");
                async.each(files, (function (file, del_cb) {
                    if ((settingsFile.indexOf(file) == -1) && (file.charAt(0) != '.' )) {
                        fs.unlink(path + '/' + file, del_cb);
                        console.log("deleting file: " + file);
                    } else
                        del_cb();
                }),function(err){

                    wget.getGroupFiles(secret, function(err) {
                        if (!err) {
                            console.log("COPIED SERVER FILES " + secret + " SUCCESSFULLY.");
                        }
                        else {
                            console.log("FAILED COPYING SERVER FILES:: " + err);
                        }
                        checkChangeAndReply();
                    })
                    saveAndReply();
                })
            })
        } else {
            saveAndReply();
        }
    }
}

function showSyncStatus () {
    if (config.btsync && settings.secret) {
        require('./btsync').getFiles(settings.secret, function(err,files){
            files.forEach(function(file) {
                if (file.state != 'deleted') {
                    console.log(file.name+':'+file.have_pieces+'/'+file.total_pieces);
                }
            })
        });
    }
    setTimeout(showSyncStatus,10000);
};

//showSyncStatus();


function checkChangeAndReply() {
    piGlobals.lastUpload = Date.now();
    fs.readFile(config.mediaPath + "__" + piGlobals.currentPlaylist + ".json", 'utf8', function (err, data) {
        if (err || !data) {
            console.log(err);
            return;
        }

        console.log(data.length);
        if (playlistContent && (playlistContent.length == data.length) && (playlistContent.indexOf(data.slice(0, 50)) == 0))
            return;

        playlistChanged = false;
        changePlaylist(function () {
            console.log("*** Changing Playlist ***");
            sendSocketIoStatus();
        })
    })
}


function checkForPlaylistChange () {

    if (!playlistChanged)  {
            setTimeout(checkForPlaylistChange,10000);
            return;
        }

    if (config.btsync && settings.secret) {
        require('./btsync').getFiles(settings.secret, function (err, files) {
            var i, len;
            for (i = 0, len = files.length; i < len; i++) {
                if ((files[i].name == ("__" + piGlobals.currentPlaylist + ".json")) &&
                    (files[i].state != 'deleted') && (files[i].have_pieces == files[i].total_pieces))
                    break;
            }
            console.log(files[i]);
            if (i == len)
                return;
            checkChangeAndReply();
        });
    } else {

    }
    setTimeout(checkForPlaylistChange,10000);
};

checkForPlaylistChange();

function runCmd (cmd) {

    console.log("executing shell command: "+cmd);

    exec(cmd,
        {
            encoding: 'utf8',
            timeout: 30000,
            maxBuffer: 20*1024,
            killSignal: 'SIGTERM',
            cwd: null,
            env: null
        },
        function(err,stdout, stderr){
            var response = {
                cmd: cmd,
                err: err,
                stdout: stdout,
                stderr: stderr
            }
            socket.emit('shell_ack',response);
        }
    );
}



