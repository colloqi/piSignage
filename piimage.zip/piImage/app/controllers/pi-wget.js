'use strict';

var spawn = require('child_process').spawn,
    fs= require('fs'),
    util = require('util');

var config = require('../../config/config');

var wgetProcess;

exports.getGroupFiles = function(groupName,callback){

    if (!groupName) {
        return callback('There is no group to fetch')
    }

    callback = callback || function() {};

    var args = [
        "-rcNnHd",
        "--no-parent",
        "-t", "10",              //infinte retries
        "--waitretry", "60",    //liear backoff algo is used in between consecutive retries.
        "--retry-connrefused",   //connection refused is considered as soft failure.
        "--no-cache"    //Asking server to not use cached versions.(to get latest even if proxy caches)
    ];

    args.push("-R");
    args.push("index.html,"+groupName);   //Remove these files if downloaded

    args.push(config.server+'/sync_folders/'+groupName);

    if (wgetProcess) {
        util.log('killing previous wget:'+ wgetProcess.pid)
        wgetProcess.kill()
    }

    wgetProcess = spawn('wget', args, {cwd: config.mediaDir, stdio:  'pipe'});
    util.log('Spawning wget '+args.toString() + '; Running as PID '+ wgetProcess.pid) ;

    wgetProcess.on('error', function(err){
        console.log ("wget spawn error: "+err);
    })

    if (!wgetProcess)
        return;

    wgetProcess.stdout.on('data', function (data) {
        console.log(data.toString());
    });

    wgetProcess.stderr.on('data', function (data) {
        console.log(data.toString());
    });

    wgetProcess.stdin.on('error', function(err){
        console.log ("wget stdin error: "+err);
    })

    wgetProcess.on('exit', function (code,signal) {
        wgetProcess.stdin.end();
        wgetProcess = null;
        util.log("wget stopped with code "+code+" and signal "+signal);
        fs.unlink(config.mediaPath+'robots.txt', function(err) {            //remove robots.txt
            if (code !== 0) {
                callback('wget process exited with code ' + code);
            }
            else {
                callback();
            }
        })
    });
};