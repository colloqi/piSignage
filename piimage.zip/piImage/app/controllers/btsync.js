'use strict';

var BTSync = require('bittorrent-sync'),
    spawn = require('child_process').spawn,
    fs = require('fs'),
    config = require('../../config/config'),
    async = require('async');

var btsync = new BTSync({
    host: 'localhost',
    port: 8888,
    username: 'api',
    password: 'secret',
    timeout: 10000
});

var btsyncProcess;

var executeShellCommand = function(cmd,cb) {
    return exec(cmd, function(err,stdout, stderr){
        if (err)
            cb(err,stderr);
        else
            cb();
    });

}

//start the btsync when server starts
exports.start=function(cb)
{
    if (btsyncProcess) {
        console.log('killing previous btsyncProcess:'+ btsyncProcess.pid)
        btsyncProcess.kill()
    }

    fs.mkdir(config.root+'/.btsyncinfo',function(err){
        if (err && (err.code != 'EEXIST')) {
            console.log("btsyncinfo creation error");
            if (cb)
                cb(err);
            return;
        }
        //var conf = (config.env =="pi")?'./btsync/btsyncRpi.conf':'./btsync/btsyncServer.conf';
        if (config.env =="pi") {
            btsyncProcess = spawn('./btsync/bin/btsync', ['--config', './btsync/btsyncRpi.conf']);
            btsyncProcess.on('error', function (err) {
                console.log("btsyncProcess spawn error: " + err);
            })
        }
        cb();
    })
}

exports.addFolderServer = function(folder,cb)
{
    var path = config.syncDirPath+folder;

    async.series([
        function(async_cb) {
            btsync.addFolder({
                dir: path       //sync folder
            }, function(err){
                if (err && err.message.slice(0,3) != '200')
                    async_cb(err);
                else
                    async_cb();

            })
        }, function(async_cb) {
            exports.getFolderSecrets(folder,async_cb);
        }
    ],function(err,result){
        console.log(result[1]);
        cb(err,result[1]);
    })

}

exports.addSecretKey = function(secret,id,cb)
{
    var settingsFile = [
        '_config.json',
        '_settings.json'
    ]
    var path = config.mediaDir,
        secretExists;

    exports.setDeviceName(id);
    btsync.getFolders(function(err,folders) {
        console.log(folders);
        if (err)
            cb(err);
        else {
            async.eachSeries(folders, function(folder,async_cb) {
                if (folder.secret != secret) {
                    btsync.removeFolder({secret: folder.secret}, function (err) {
                        console.log("btsync remove folder: " + folder.dir);
                        fs.readdir(folder.dir, function (err, files) {
                            if (err)
                                return async_cb(err);
                            async.each(files, (function (file, del_cb) {
                                if ((settingsFile.indexOf(file) == -1) && (file.charAt(0) != '.' )) {
                                    fs.unlink(path + '/' + file, del_cb);
                                    console.log("deleting file: " + file);
                                } else
                                    del_cb();
                            }), async_cb)
                        })
                    })
                } else {
                    secretExists = true;
                    console.log("secret exists, not being newly added");
                    async_cb();
                }
            }, function(err) {
                if (err)
                    cb(err);
                else {
                    if (secretExists)
                        return cb();

                    btsync.addFolder({
                        dir: path,         //path on pi
                        secret: secret     //secret given by server RO for one way sync
                    }, cb)
                }
            })
        }
    })
}



// API returns RO and RW secret.
// This secret need to be stored for this folder in DB, after calling btsyncServerAddFolder
// The RO secret need to shared with client for adding folder in RO mode.

exports.getFolderSecrets = function(folder,cb)
{
    var path = config.syncDirPath+folder,
        folderData;
    btsync.getFolders(function(err,folders) {

        for (var i= 0,len = folders.length;i<len;i++) {
            if (folders[i].dir.slice(folders[i].dir.lastIndexOf('/')+1) == folder) {
                folderData = folders[i];
                break;
            }
        }

        if(folderData){
            btsync.getSecrets({secret: folderData.secret}, function (err, secret) {
                cb(err,secret)          //returns RO and RW secret.
            });
        } else {
            cb("No sync for this folder");
        }
    });
}


exports.removeFolderServer = function(folder,cb)
{
    var path = config.syncDirPath+folder,
        folderData;

    btsync.getFolders(function(err,folders) {
        for (var i= 0,len = folders.length;i<len;i++) {
            if (folders[i].dir.slice(folders[i].dir.lastIndexOf('/')) == folder) {
                folderData = folders[i];
                break;
            }
        }

        if(folderData){
            btsync.removeFolder({secret: folderData.secret}, function (err) {
                if (err)
                    cb(err);
                else {
                    fs.rmdir(path,function(err){
                        cb(err);
                    })
                }
            });
        } else {
            cb("No sync for this folder");
        }

    });
}

exports.removeAllFoldersServer = function(path,cb)
{   var path;
    btsync.getFolders(function(err,folders) {
        for (var i=0; i<folders.length;i++){
           console.log(folders[i].dir)
            path=folders[i].dir;
            btsync.removeFolder({
                secret: folders[i].secret
            }, function (err) {
                if(err) cb(err);
                console.log(path)
                exec("rm -r "+path)
                cb("folder removed:   " +path);
            });
        }
    });
}

//Use this api on server to find out the sync status of peers.

exports.getPeerStatus=function(secret,cb)
{
    var syncTime = [];
    btsync.getFolderPeers({
        secret: secret
    }, function (err, result) {
        if (!err && result.length > 0) {
            result.forEach(function (node) {
                console.log("Last sync for "+node.name+": "+(new Date(node.synced * 1000)).toLocaleString());
                syncTime.push({name:node.name,synced:node.synced});
            });
            cb(syncTime);
        } else {
            console.log("There are no sync folders");
            cb();
        }
    })
}

exports.setDeviceName= function (name) {
    btsync.setPrefs({
        device_name: name
    },function(err,data){
        if (err)
            console.log("error in setting the btsync name: "+err);
        else
            console.log("player name is set as: ",data.device_name);
    })
}

exports.getFiles= function (secret,cb) {
    btsync.getFiles({
        secret: secret
    },cb)
}


//exports.btsyncStart(function(){console.log(err) });
var pathtest='Group';
var foldersecret="";
var secret_ro='BETNCB4IUQLBEEA5VDXULKYR26QAIEHFH'
var secret_rw='AAQSMM72KRCC4WHSZPZ4NLBZWXQM6GZWN'
var clientpath="/var/tmp/ttk";
//exports.addFolderServer(pathtest,function(err){console.log(err); });
//exports.getFolderSecrets(pathtest,function(err,secret){console.log(secret);foldersecret=secret;});
//exports.btsyncServerRemoveFolder(pathtest,function(err){console.log(err); });
//exports.btsyncServerRemoveAllFolders(pathtest,function(err){console.log(err); });
//exports.btsyncClientAddFolder(clientpath,function(err){console.log(err); }, secret_ro);
//exports.getPeerStatus()
//TBD: directory creation for syncpath
//btsync.getFolders(function(err,folders) {
//    console.log ("Sync folders present: ");
//    console.log(folders);
//})
