'use strict';

var config = require('../../config/config'),
    rest = require('../others/restware'),
    fs = require('fs'),
    path = require('path'),
    async = require('async');


var isPlaylist = function(file){
    return (file.charAt(0) == '_' && file.charAt(1) == '_');
}

exports.index= function(req, res){

    fs.readdir(config.mediaPath, function(err, files){
        if(err) {
            return rest.sendError(res, 'directory read error', err);
        } else {
            var playlists = files.filter(isPlaylist),
                list = [];

            var readFile = function (plfile, cb) {
                var playlist = {
                    settings: {},
                    assets: [],
                    name: path.basename(plfile, '.json').slice(2)
                }
                fs.readFile(config.mediaPath+plfile,'utf8',function(err,data){
                    if (err || !data)
                        list.push(playlist) ;
                    else {
                        var obj = JSON.parse(data);
                        playlist.settings = obj.settings || {};
                        playlist.assets = obj.assets || [];
                        list.push(playlist);
                    }
                    cb();
                })
            }

            async.each(playlists,readFile,function(err){
                if (err) {
                    return rest.sendError(res, 'playlist read error', err);
                } else {
                    return rest.sendSuccess(res, ' Sending playlist list', list);
                }
            })

        }
    });

}

exports.getPlaylist = function(req,res) {

    var file= config.mediaPath + "__" + req.params['file']+'.json';
    fs.readFile(file, 'utf8', function (err, data) {
        if (err) {
            return rest.sendError(res, 'playlist file read error', err);
        } else {
            var playlist = {
                settings: {},
                assets: []
            }
            if (data) {
                var obj = JSON.parse(data);
                playlist.settings = obj.settings || {};
                playlist.assets = obj.assets || [];
            }

            return rest.sendSuccess(res, ' Sending playlist content', playlist);
        }
    });
}

exports.createPlaylist= function(req, res){
    var file= config.mediaPath+"__"+req.body['file']+'.json';
    fs.writeFile(file, '', function (err) {
        if(err) {
            rest.sendError(res, "Playlist write error",err);
        } else {
            rest.sendSuccess(res, "Playlist Created: ", file);
        }
    });
}

exports.savePlaylist= function(req, res){
    var file= config.mediaPath + "__" + req.params['file']+'.json';

    fs.readFile(file, 'utf8', function (err, data) {
        if (err ) {
            rest.sendError(res,"Playlist file read error", err)
        } else {
            var fileData = {}, dirty = false;
            fileData.version = 0;

            if (data) {
                fileData = JSON.parse(data);
                fileData.version = data.version || 0;
            }
            if (req.body.settings) {
                fileData.settings = req.body.settings;
                dirty = true;
            }

            if (req.body.assets) {
                fileData.assets = req.body.assets;
                dirty = true;
            }

            if (dirty) {
                fileData.version +=1;
                fs.writeFile(file, JSON.stringify(fileData, null, 4), function(err) {
                    if(err) {
                        rest.sendError(res, "Playlist save error", err);
                    } else {
                        rest.sendSuccess(res, "Playlist Saved: ", fileData);
                    }
                });
            } else {
                rest.sendSuccess(res, "Nothing to Update: ", fileData);
            }
        }
    });

}

