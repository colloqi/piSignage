'use strict';
var spawn = require('child_process').spawn,
    exec = require('child_process').exec,
    util = require('util'),
    fs= require('fs');

var config = require('../../config/config');

var browser, currentBrowserUrl,browserReady=true,browserCommand, previousBrowserCommand, watchdogUzbl,retryCount,
    omxProcess, videoPaused,watchdogVideo,browserTimer;

var BLANK_HTML = config.root + "/app/views/blank.html";

var playlistOn = false, //used locally in this file
    playFiles = [],     //stores the playlistfiles
    nextFileIndex = 0,
    callbackCount = 0;

var omxCommands = {
        'pause' : 'p',
        'quit' : 'q'
    };

var videoWindowSize = '0 0 1279 719';
    
//load the browser instance
loadBrowser();

//browser utilities
function loadBrowser (url) {
    if (browser) {
        util.log('killing previous uzbl:'+ browser.pid)
        browser.kill()
    }

    if (url)
        currentBrowserUrl = url;
    else
        currentBrowserUrl = BLANK_HTML;

    browser = spawn('uzbl',['-g','maximized','-c','-','--uri',currentBrowserUrl,'-p'],{stdio :  'pipe'})
    util.log('Browser loading '+currentBrowserUrl+'; Running as PID '+ browser.pid)

    browser.on('error', function(err){
        console.log ("browser spawn error: "+err);
    })

    if (!browser)
        return;

    browser.once('exit', function(code, signal) {
        browser = null;
        util.log("browser stopped with code "+code+" and signal "+signal);
    });

    browser.stdout.on('data', function(data){
        var line = data.toString('utf8');
        var pbr = browserReady;
        if (previousBrowserCommand) {
            if ((previousBrowserCommand.indexOf('uri') == 0)  && (line.indexOf('LOAD_FINISH') >=0 )) {
                browserReady = true;
                clearTimeout(watchdogUzbl);
            }
            if ((previousBrowserCommand.indexOf('uri') != 0)  && (line.indexOf('COMMAND_EXECUTED') >=0 )) {
                browserReady = true;
                clearTimeout(watchdogUzbl);
            }
            if (!pbr && browserReady) {
                //console.log("uzbl stdout: "+line);
                //console.log("Completion event for cmd: "+previousBrowserCommand.toString());
            }
        }
    })

    browser.stderr.on('data', function(data){
        console.log("uzbl stderr: "+data.toString('utf8'));
    })

    browser.stdin.on('error', function(err){
        console.log ("browser stdin error: "+err);
    })

    browser.stdin.write(fs.readFileSync(config.root + '/misc/uzblrc') + '\n', function(err){
        if (err) util.log("uzbl command callback error: "+err)
    })

    browserDefault();

}

function browserSend (cmd) {
    if (!cmd && !browserCommand) {
        util.log("Browser: No command to issue")
        return;
    }
    if (cmd)  {          //only one command can be waiting
        browserCommand = cmd;
        retryCount = 0;
    } else {
        retryCount++;
    }

    if (!browserReady) {
        setTimeout(browserSend,500);
        return;
    }

    //util.log("Browser command: "+browserCommand+", retry count ="+retryCount);
    if (browser) {
        try {
            browserReady = false;
            previousBrowserCommand = browserCommand;
            watchdogUzbl = setTimeout(function(){browserReady=true;console.log("uzbl: no completion event: "+browserCommand)},3000);     //after timeout make it true if event does not occur
            browser.stdin.write(browserCommand + '\n', function(err){
                if (err) util.log("uzbl command callback error: "+err)
            })
        } catch (e) {
            util.log("browser stdin write exception: "+e.code);
        }
    } else {
        util.log("No browser instance, restarting the browser")
        loadBrowser();
    }
    browserCommand = null;
}

function browserDefault() {
    clearTimeout(browserTimer);
    browserSend("uri "+BLANK_HTML);
    currentBrowserUrl = BLANK_HTML;
}

function clearMainDiv () {
    clearTimeout(browserTimer);
    browserSend('js window.clearmain()');
}

function setMainDiv (path) {
    browserSend('js window.setmain("'+encodeURI(path)+'")');
}

function clearTicker () {
    videoWindowSize = '0 0 1279 719';
    browserSend('js window.clearticker()');
}

function setTicker (text) {
    videoWindowSize = '0 0 1279 659';
    browserSend('js window.setticker("'+encodeURIComponent(text)+'")');
}

function loadImage(path) {
    //browserDefault();
    browserSend('js window.setimg("'+encodeURI(path)+'")');
    //browserSend('js '+ 'document.body.style.backgroundImage = "url(\'.'+ path +"')\"" ) ;
}

//omxplayer utilities

function openOmxPlayer (file,cb) {

    omxProcess = spawn("omxplayer", ['--win',videoWindowSize,'-o', 'hdmi', file], {
        stdio : [ 'pipe', null, null ]
    });

    omxProcess.once('exit', function(code, signal) {
        exec('killall /usr/bin/omxplayer.bin');
        omxProcess = null;
        clearTimeout(watchdogVideo);
        cb();
    });
}


function omxSend (action) {
    if (omxCommands[action] && omxProcess) {
        try {
            omxProcess.stdin.write(omxCommands[action], function(err) {
                util.log("omxplayer command callback error: "+err);
            });
        } catch (err) {
            util.log("omxplayer stdin write exception: "+err);
        }
    } else {
        util.log("No omxplayer instance or omxplayer command not found: "+action);
    }
};

function playVideo (file,cb,restart) {
    //browserDefault();
    clearMainDiv();
    //util.log("play video: "+file)
    if (restart)
        stopVideo();        //kill the current video
    if (omxProcess) {
        if (!videoPaused) {
            return false;
        }
        omxSend('pause');
        videoPaused = false;
        return true;
    } else {
        openOmxPlayer(file,cb);
        return true;
    }
};

function pauseVideo () {
    if (videoPaused) {
        return false;
    } else {
        omxSend('pause');
        videoPaused = true;
        return true;
    }
};


function stopVideo() {
    if (!omxProcess) {
        return false;
    } else {
        //util.log("stop video")
        //omxSend('quit');
        omxProcess.kill();
        omxProcess = null;
        return true;
    }
};

function displayNext(fname, duration,cb) {
    //check for video
    callbackCount +=1;
    if (!duration || duration < 5)
        duration = 5;
    var filepath= config.mediaPath+fname;
    fs.stat(filepath,function(err,stats){
        if (err || !stats.isFile())
            return cb();                   //goto the next file, if the file does not exist

        util.log("playing next file: "+fname +' time = ' + duration+';'+callbackCount);
        if(fname.match(/(mp4|mov|m4v)$/i)){
            playVideo(filepath ,cb, true );
            clearTimeout(watchdogVideo);
            watchdogVideo = setTimeout(function(){
                util.log("watchdog Timeout expired, killing video process")
                stopVideo();
            },10*60*1000);
        } else if(fname.match(/(jpg|jpeg|png|gif)$/i)) {
            loadImage(filepath);
            clearTimeout(browserTimer);
            browserTimer = setTimeout(function(){
                //util.log("image duration expired")
                cb();
            },1000*duration)
        } else {
            //browserSend("uri "+filepath);
            //currentBrowserUrl = filepath;
            setMainDiv(filepath);
            clearTimeout(browserTimer);
            browserTimer = setTimeout(function () {
                //util.log("html duration expired")
                cb();
            }, 1000 * duration)
        }
    })
}

var scheduler = function(err) {
    callbackCount = callbackCount - 1;
    if (playlistOn) {
        if (callbackCount <=0) {
            nextFileIndex = (nextFileIndex + 1) % playFiles.length;
            displayNext(playFiles[nextFileIndex].filename, playFiles[nextFileIndex].duration, scheduler);
            if (i==0) {
                exec("echo 'on 0' | cec-client -s", function(error){
                    if (error)
                        console.log("TV command error: "+error);
                    exec("echo 'as' | cec-client -s");
                });
            }
        }  else {
            console.log("*** callback is greater than 0: "+callbackCount);
        }
    }
}

exports.startPlay = function (files,ticker)  {

    if (playlistOn) {
        clearTimeout(browserTimer);
        clearTimeout(watchdogVideo);
    }
    callbackCount = 0;
    playlistOn = true;
    exec("echo 'on 0' | cec-client -s", function(error){
        if (error)
            console.log("TV command error: "+error);
        exec("echo 'as' | cec-client -s");
    });

    nextFileIndex = 0;
    var len = files?files.length:0;

    if (len > 0) {
        if (ticker)
            setTicker(ticker);
        else
            clearTicker();
        playFiles = files;
        displayNext(playFiles[nextFileIndex].filename,playFiles[nextFileIndex].duration ,scheduler);
        return;
    } else {
        playlistOn = false;
        return ("No files to Play");
    }
}

exports.stopPlay = function ()  {
    playlistOn = false;
    browserDefault();
    stopVideo();
    exec("echo 'standby 0' | cec-client -s");
    return;
}
