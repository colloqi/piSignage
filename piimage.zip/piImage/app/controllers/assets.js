'use strict';

var config = require('../../config/config'),
    rest = require('../others/restware'),
    fs = require('fs'),
    path = require('path'),
    async = require('async'),
    jade = require('jade');

var mainCtrl;

if (config.env == "pi")
    mainCtrl = require('./pi-main');
else
    mainCtrl = require('./server-main');

exports.index = function(req,res) {

    fs.readdir(config.mediaDir, function (err, data) {
        if (err) {
            return rest.sendError(res, "Error reading media directory: " + err)
        } else {
            var files = data.filter(function (file) {
                return (file.charAt(0) != '_' && file.charAt(0) != '.');
            });
            return rest.sendSuccess(res, "Sending media directory files: ", files)
        }
    });
}


exports.createFiles = function(req, res){

    var files = Object.keys(req.files),
        data = [];

    async.each(files,renameFile,function(err){
        mainCtrl.writeToConfig({lastUpload:Date.now()});
        mainCtrl.updateDiskStatus();
        if (err) {
            console.log(data);
            return rest.sendError(res, 'File rename error', err);
        } else {
            return rest.sendSuccess(res, ' Successfully uploaded files', data);
        }
    })

    function renameFile (file, cb) {
        var fileObj = req.files[file];
        fs.rename(fileObj.path, config.mediaPath + fileObj.name, function(err){
            if(err) {
                console.log("file rename error:" + err);
                cb(err);
            } else {
                data.push({ name: fileObj.name,
                            size: fileObj.size,
                            type: fileObj.type
                        });
                cb();
            }
        });
    }

}

exports.getFileDetails = function(req, res){
    var file= req.params['file'];

    fs.stat(config.mediaPath + file,function (err, data) {
        if (err) {
            return rest.sendError(res, 'file stat error', err);
        } else {
            return rest.sendSuccess(res, 'Sending file details',
                                                    {   name: file,
                                                        size: ~~(data.size/1000)+' KB',
                                                        ctime: data.ctime
                                                    });
        }
    })
}

exports.deleteFile = function(req, res){

    var file = req.params['file'],
        ext =  path.extname(file),
        jsonFile;

    if (ext == ".html")
        jsonFile = "_" + path.basename(file,ext)+'.json';

    fs.unlink(config.mediaPath+file, function(err){
        if (err) {
            rest.sendError(res, "Unable to delete file",err)
        }
        mainCtrl.updateDiskStatus();
        if (jsonFile)
            fs.unlink(config.mediaPath+jsonFile, function(err){
                return rest.sendSuccess(res, 'Deleted file',file);
            });
        else
            return rest.sendSuccess(res, 'Deleted file',file);
    })

}

exports.renameFile = function(req, res) {
    var oldName = req.params['file'],
        jsonFile = '_' + oldName.slice(0,oldName.lastIndexOf('.')) + '.json',
        newName = req.body.newname,
        newJsonFile = '_' + newName.slice(0,newName.lastIndexOf('.')) + '.json';

    fs.rename(config.mediaPath+oldName, config.mediaPath+newName, function (err) {
        if (err) {
            return rest.sendError(res, 'File rename error', err);
        } else {
            fs.rename(config.mediaPath+jsonFile, config.mediaPath+newJsonFile, function (err) {
                if (err)
                    console.log(err);//check for ENOENT, else send error
                return rest.sendSuccess(res, ' Successfully renamed file to', newName);
            })
        }
    });
}

exports.createNotice = function(req, res){
    var data= req.body.formdata,
        template= fs.readFileSync(config.defaultTemplate,'utf8');

    var options= {
        filename: 'noticecss.css',
        pretty: true,
        compileDebug: false
    }

    var compile = jade.compile(template, options);

    var html = compile({
        title: data.title,
        description: data.description,
        image: data.image,
        footer: data.footer
    });

    var jsonContent = {
        title: data.title,
        description: data.description,
        image: data.image || '',
        footer: data.footer || ''
    };

    var noticename;
    if (req.params['file'])
        noticename = path.basename(req.params['file'],'.html');
    else
        noticename = data.title.slice(0,20).replace(/\W/g, '')+'_'+Math.floor(Math.random()*10000);

    fs.writeFile(config.mediaPath+noticename+'.html', html, 'utf8', function(err){
        if(err){
            rest.sendError(res,'Error writing html file: ', err)
        }else{
            fs.writeFile(config.mediaPath+"_"+noticename+'.json',
                JSON.stringify(jsonContent, null, 4), 'utf8', function(err){
                    if (err) {
                        rest.sendError(res,'Error writing json file: ', err)
                    } else {
                        mainCtrl.writeToConfig({lastUpload:Date.now()});
                        mainCtrl.updateDiskStatus();
                        rest.sendSuccess(res, 'Notice File Saved', html);
                    }
                });
        }
    });
}

exports.getNotice = function(req, res){

    var jsonFile = "_" + path.basename(req.params['file'],'.html')+'.json';
    fs.readFile(config.mediaPath + jsonFile, 'utf8', function (err, data) {
        if (err) {
            return rest.sendError(res, 'JSON file read error', err);
        } else {
            return rest.sendSuccess(res, 'Sending notice file details', data? JSON.parse(data): null);
        }
    });
}



