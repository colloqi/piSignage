#!/bin/sh
####################################################################
# this script will take care of new release and auto update (modules should be attached)
#first kill forever process
#remove the current folder
#get file from the link
#change ownership
#reboot
#####################################################################

# kill forever process
pkill -f forever
pkill node
pkill uzbl

#update and updrade
cd ~
sudo apt-get -qq update
sudo apt-get -y -qq upgrade

echo " updating"
rm -rf /tmp/package.json
rm -rf ~/piSignagePro
wget https://www.dropbox.com/s/jwjln6lhe25n7mc/piimage.zip

unzip ./*.zip
cp -f -R ~/piImage/* ~/piSignagePro/
rm -rf ~/*.zip
rm -rf ~/piImage
cd ~/piSignagePro
#sudo sh newchanges.sh
sudo npm install
echo "installing packages"
sudo chmod 777 -R ~/piSignagePro
sudo reboot

